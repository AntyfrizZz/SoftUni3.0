﻿namespace _10InfernoInfinity
{
    public enum WeaponTypes
    {
        Axe,
        Sword,
        Knife
    }
}