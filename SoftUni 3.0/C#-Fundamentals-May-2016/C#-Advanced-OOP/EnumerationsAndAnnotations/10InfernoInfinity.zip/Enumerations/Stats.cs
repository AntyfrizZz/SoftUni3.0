﻿namespace _10InfernoInfinity
{
    public enum Stats
    {
        Strength,
        Agility,
        Vitality
    }
}