﻿namespace _10InfernoInfinity
{
    public enum GemClarities
    {
        Chipped = 1,
        Regular = 3,
        Perfect = 5,
        Flawless = 10
    }
}