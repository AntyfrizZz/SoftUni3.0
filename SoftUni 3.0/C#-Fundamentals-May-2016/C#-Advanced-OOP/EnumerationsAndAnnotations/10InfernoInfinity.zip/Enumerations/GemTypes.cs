﻿namespace _10InfernoInfinity
{
    public enum GemTypes
    {
        Ruby,
        Emerald,
        Amethyst
    }
}