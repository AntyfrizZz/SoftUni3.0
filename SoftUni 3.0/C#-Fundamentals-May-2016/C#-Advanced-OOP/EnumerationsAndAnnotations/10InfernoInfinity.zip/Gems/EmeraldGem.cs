﻿namespace _10InfernoInfinity.Gems
{
    public class EmeraldGem : Gem
    {
        private const int StrengthIncrease = 1;
        private const int AgilityIncrease = 4;
        private const int VitalityIncrease = 9;

        public EmeraldGem(
            GemTypes gemType,
            GemClarities gemClarity) 
            : base(
                  gemType, 
                  gemClarity,
                  StrengthIncrease,
                  AgilityIncrease,
                  VitalityIncrease)
        {
        }
    }
}