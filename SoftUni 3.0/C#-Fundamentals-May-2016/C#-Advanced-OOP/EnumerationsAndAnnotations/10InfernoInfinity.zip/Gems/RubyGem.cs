﻿namespace _10InfernoInfinity.Gems
{
    public class RubyGem : Gem
    {
        private const int StrengthIncrease = 7;
        private const int AgilityIncrease = 2;
        private const int VitalityIncrease = 5;

        public RubyGem(
            GemTypes gemType, 
            GemClarities gemClarity) 
            : base(
                  gemType, 
                  gemClarity,
                  StrengthIncrease,
                  AgilityIncrease,
                  VitalityIncrease)
        {
        }
    }
}