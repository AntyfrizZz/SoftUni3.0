﻿namespace _12Refactoring.Interfaces.IO
{
    public interface IExecutable
    {
        void Execute();
    }
}
