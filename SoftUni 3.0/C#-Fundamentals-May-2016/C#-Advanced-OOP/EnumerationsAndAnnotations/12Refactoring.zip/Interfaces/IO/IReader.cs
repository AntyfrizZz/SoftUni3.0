﻿namespace _12Refactoring.Interfaces.IO
{
    public interface IReader
    {
        void StartReadingCommands();
    }
}
