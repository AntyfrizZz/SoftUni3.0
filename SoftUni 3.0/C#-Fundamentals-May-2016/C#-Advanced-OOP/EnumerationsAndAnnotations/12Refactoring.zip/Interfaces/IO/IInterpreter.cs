﻿namespace _12Refactoring.Interfaces.IO
{
    public interface IInterpreter
    {
        void InterpretCommand(string command);
    }
}
