﻿namespace _12Refactoring.Enumerations
{
    public enum GemTypes
    {
        Ruby,
        Emerald,
        Amethyst
    }
}