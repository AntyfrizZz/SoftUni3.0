﻿namespace _12Refactoring.Enumerations
{
    public enum WeaponTypes
    {
        Axe,
        Sword,
        Knife
    }
}