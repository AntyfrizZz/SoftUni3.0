﻿namespace _12Refactoring.Enumerations
{
    public enum Stats
    {
        Strength,
        Agility,
        Vitality
    }
}