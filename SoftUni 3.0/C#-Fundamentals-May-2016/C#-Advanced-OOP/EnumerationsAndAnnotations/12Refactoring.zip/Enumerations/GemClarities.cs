﻿namespace _12Refactoring.Enumerations
{
    public enum GemClarities
    {
        Chipped = 1,
        Regular = 2,
        Perfect = 5,
        Flawless = 10
    }
}