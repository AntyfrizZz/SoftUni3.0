﻿namespace _08.Military_Elite.Interfaces
{
    public interface ISpy : ISoldier
    {
        string CodeNumber { get; }
    }
}
