﻿namespace SystemSplit
{
    public abstract class Components
    {
        #region Constructors

        protected Components(string name)
        {
            this.Name = name;
        }

        #endregion Constructors

        //===================================================================

        #region Properties

        public string Type { get; protected set; }

        public string Name { get; }

        #endregion Properties
    }
}