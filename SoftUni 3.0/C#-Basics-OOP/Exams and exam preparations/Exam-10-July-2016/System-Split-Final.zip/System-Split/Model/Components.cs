﻿namespace SystemSplit
{
    public abstract class Components
    {
        #region Fields

        #endregion Fields

        //===================================================================

        #region Constructors

        protected Components(string name)
        {
            this.Name = name;
        }

        #endregion Constructors

        //===================================================================

        #region Properties

        public string Type { get; protected set; }

        public string Name { get; }

        #endregion Properties

        //===================================================================

        #region Methods

        #endregion Methods

    }
}