﻿using System;

namespace SystemSplit
{
    public class PowerHardware : Hardware
    {
        #region Fields

        private const double capacityRatio = 0.25;
        private const double memoriRatio = 1.75;

        #endregion Fields

        //===================================================================

        #region Constructors

        public PowerHardware(string name, int maximumCapacity, int maximumMemory)
            : base(name, (int)(maximumCapacity * capacityRatio), (int)(maximumMemory * memoriRatio))
        {
            base.Type = "Power";
        }

        #endregion Constructors

        //===================================================================

        #region Properties

        #endregion Properties

        //===================================================================

        #region Methods

        #endregion Methods
    }
}